const express = require('express');
const axios = require('axios');
const app = express();
app.use(express.json());

// 🔹 Base de eventos armazenados por tipo
const eventos = {};

// 🔹 Registro de interesses dos microsserviços
// Ex: { logs: ['LembreteCriado', 'ObservacaoCriada'], classificacao: ['ObservacaoCriada'] }
const interesses = {};

// 🔹 Endpoint para registrar interesses
app.post('/registrar', (req, res) => {
  const { nome, eventosInteresse } = req.body;
  interesses[nome] = eventosInteresse;

  console.log(`📢 Microsserviço '${nome}' registrado com interesse em:`, eventosInteresse);

  // 🔹 Enviar eventos passados (perdidos) para o microsserviço
  eventosInteresse.forEach(tipo => {
    if (eventos[tipo]) {
      eventos[tipo].forEach(ev => {
        try {
          axios.post(`http://localhost:${portas[nome]}/eventos`, ev);
        } catch (e) {}
      });
    }
  });

  res.status(200).send({ status: 'Interesses registrados com sucesso' });
});

// 🔹 Mapeamento de nomes para portas
const portas = {
  lembretes: 4000,
  observacoes: 5000,
  consulta: 6000,
  classificacao: 7000,
  logs: 8000,
  estatisticas: 9000
};

// 🔹 Recebimento de eventos
app.post('/eventos', async (req, res) => {
  const evento = req.body;
  console.log('\n🚏 Evento recebido no barramento:', evento);

  // 🔹 Salvar evento por tipo
  if (!eventos[evento.type]) {
    eventos[evento.type] = [];
  }
  eventos[evento.type].push(evento);

  // 🔹 Distribuir apenas para microsserviços interessados
  for (let nome in interesses) {
    if (interesses[nome].includes(evento.type)) {
      try {
        await axios.post(`http://localhost:${portas[nome]}/eventos`, evento);
        console.log(`📨 Evento enviado para: ${nome}`);
      } catch (e) {
        console.log(`⚠️ Falha ao enviar evento para ${nome}`);
      }
    }
  }

  res.end();
});

// 🔹 Endpoint para verificar eventos armazenados
app.get('/eventos', (req, res) => {
  res.json(eventos);
});

const port = 10000;
app.listen(port, () => {
  console.log(`🚏 Barramento de eventos. Porta ${port}.`);
});
