import express from 'express';
import axios from 'axios';

const app = express();
app.use(express.json());

// 🔹 Palavra-chave usada para classificação
const palavraChave = 'importante';

// 🔹 Funções separadas por tipo de evento
const funcoes = {
  ObservacaoCriada: (observacao) => {
    if (observacao.texto.includes(palavraChave)) {
      observacao.status = 'importante';
    } else {
      observacao.status = 'comum';
    }

    axios.post('http://localhost:10000/eventos', {
      type: 'ObservacaoClassificada',
      payload: observacao
    }).catch(() => {});
  },

  LembreteCriado: (lembrete) => {
    if (lembrete.texto.length >= 50) {
      lembrete.status = 'importante';
    } else {
      lembrete.status = 'comum';
    }

    axios.post('http://localhost:10000/eventos', {
      type: 'LembreteClassificado',
      payload: lembrete
    }).catch(() => {});
  }
};

// 🔹 Receber eventos vindos do barramento
app.post('/eventos', (req, res) => {
  const evento = req.body;
  console.log('📨 Evento recebido na Classificação:', evento);

  try {
    const funcao = funcoes[evento.type];
    if (funcao) {
      funcao(evento.payload);
    }
  } catch (e) {}

  res.end();
});

// 🔹 Subir servidor e registrar interesse
const port = 7000;
app.listen(port, async () => {
  console.log(`🚀 Classificação. Porta ${port}.`);

  // 🔹 Registrar quais eventos tem interesse
  axios.post('http://localhost:10000/registrar', {
    nome: 'classificacao',
    eventosInteresse: ['ObservacaoCriada', 'LembreteCriado']
  }).catch(() => {});

  // 🔹 Recuperar eventos antigos armazenados no barramento
  try {
    const { data: eventos } = await axios.get('http://localhost:10000/eventos');

    if (eventos && typeof eventos === 'object') {
      for (const tipo in eventos) {
        for (const evento of eventos[tipo]) {
          try {
            const funcao = funcoes[evento.type];
            if (funcao) {
              funcao(evento.payload);
            }
          } catch (e) {}
        }
      }
    }
  } catch (e) {}
});
